package org.jdom2.test.cases.serialize;

import org.jdom2.Element;

@SuppressWarnings("javadoc")
public class SElement extends Element {

	private static final long serialVersionUID = 1L;

}
