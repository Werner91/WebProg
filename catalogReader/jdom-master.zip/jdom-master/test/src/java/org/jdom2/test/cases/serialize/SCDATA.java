package org.jdom2.test.cases.serialize;

import org.jdom2.CDATA;

@SuppressWarnings("javadoc")
public class SCDATA extends CDATA {

	private static final long serialVersionUID = 1L;

}
