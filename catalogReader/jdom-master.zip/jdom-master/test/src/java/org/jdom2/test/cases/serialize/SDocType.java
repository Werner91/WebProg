package org.jdom2.test.cases.serialize;

import org.jdom2.DocType;

@SuppressWarnings("javadoc")
public class SDocType extends DocType {

	private static final long serialVersionUID = 1L;

}
