package org.jdom2.test.cases.serialize;

import org.jdom2.ProcessingInstruction;

@SuppressWarnings("javadoc")
public class SProcessingInstruction extends ProcessingInstruction {

	private static final long serialVersionUID = 1L;

}
