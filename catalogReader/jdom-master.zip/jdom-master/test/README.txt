Introduction
============

this 'test' folder is the home for a set of test cases covering all aspects
of JDOM behavior, used to ensure the JDOM core library consistently behaves as
documented.  My expectation is that we'll run these tests before every
check-in.  Currently the module includes a set of JUnit library.  Your help in
fleshing out the test cases is most welcome.  Send patches to the
jdom-interest list.

You can run the test cases with 'ant junit' in the parent directory.

